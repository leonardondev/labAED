#include "ListTemplate.h"
using namespace std;

#ifndef TOPSORT_H
#define TOPSORT_H

typedef int TaskType;  // tipo de tarefa

class TopSort
{ public:
    TopSort(string projectName = "Unnamed project");
    ~TopSort();
    int GetNodes();
    int GetEdges();
    string GetProjectName();
    void Clear();
    void AddRelation(TaskType x, TaskType y);
    List<TaskType> FindTopSort();

  private:
    // definicao de tipos
    struct leader;   // declaracoes incompletas, pois leader e trailer sao dependentes entre si
    struct trailer;  // declaracoes completas mais abaixo no codigo
 
    typedef leader  * leaderPointer;
    typedef trailer * trailerPointer;

    struct leader
    { TaskType task;          
      int      predecessors;       // numero de precedessores da tarefa task
      leaderPointer  nextLeader;
      trailerPointer nextTrailer;
    };

    struct trailer
    { leaderPointer  nextLeader;
      trailerPointer nextTrailer;
    };

    // definicao de campos do objeto
    leaderPointer head, sentinel; // inicio e final da estrutura de dados
    string projectName;           // nome do projeto (grafo)
    int nodes;                    // numero de elementos no grafo
    int edges;                    // numero de arestas no grafo

    // definicao de metodos privados
    leaderPointer InsertNode(TaskType task);
    void InsertEdge(leaderPointer &p, leaderPointer &q);
};

#endif /* TOPSORT_H */
