#include "TopSort.h"
using namespace std;

//------------------------------------------------------------------------------------------------------------
// pre: nenhum
// pos: inicializa campos do objeto representando nenhum noh e nenhuma aresta; cria sentinela
TopSort::TopSort(string projectName)
{ sentinel = new leader;
  head = sentinel;
  nodes = edges = 0;
  this->projectName = projectName;
}
//------------------------------------------------------------------------------------------------------------
// pre: objeto criado
// pos: libera espaco ocupado pelos elementos, incluindo sentinela
TopSort::~TopSort()
{ Clear();
  delete sentinel;
}
//------------------------------------------------------------------------------------------------------------
// pre: objeto criado
// pos: retorna o numero de nohs no grafo
int TopSort::GetNodes()
{ return nodes;
}
//------------------------------------------------------------------------------------------------------------
// pre: objeto criado
// pos: retorna o numero de arestas no grafo
int TopSort::GetEdges()
{ return edges;
}
//------------------------------------------------------------------------------------------------------------
// pre: objeto criado
// pos: retorna o nome do projeto
string TopSort::GetProjectName()
{ return projectName;
}
//------------------------------------------------------------------------------------------------------------
// pre: objeto criado
// pos: libera espaco ocupados pelos elementos e torna a estrutura vazia, pronta para ser reutilizada;
//      projectName contem "Unnamed project"
void TopSort::Clear()
{ // implementar
}
//------------------------------------------------------------------------------------------------------------
// pre: objeto criado
// pos: adiciona nohs x e y como tambem aresta x < y na estrutura
void TopSort::AddRelation(TaskType x, TaskType y)
{ leaderPointer p,q;

  p = InsertNode(x);
  q = InsertNode(y);
  InsertEdge(p,q);              
}
//------------------------------------------------------------------------------------------------------------
// pre: objeto criado
// pos: retorna ordem topologia em uma lista (se tamanho da lista for igual ao numero de nohs no diagrama)
List<TaskType> TopSort::FindTopSort()
{ // implementar
}
//------------------------------------------------------------------------------------------------------------
// pre: objecto criado, contendo sentinela
// pos: realiza busca com insercao da tarefa task; retorna um ponteiro para o noh onde se encontra task
TopSort::leaderPointer TopSort::InsertNode(TaskType task)
{ // implementar...
}
//------------------------------------------------------------------------------------------------------------
// pre: no's p e q jah estao inseridos na estrutura de dados 
// pos: insere aresta p < q
void TopSort::InsertEdge(leaderPointer &p, leaderPointer &q)
{ // implementar...
}
//------------------------------------------------------------------------------------------------------------
