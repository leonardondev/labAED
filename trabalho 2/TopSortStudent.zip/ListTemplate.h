#include <iostream>
#include <cstring>
#include <cstdlib>
#include <sstream>
using namespace std;

#ifndef LISTTEMPLATE_H
#define LISTTEMPLATE_H

template< class ListEntry >
class List
{ public:
    List();
    ~List();
    bool Empty();
    bool Full();
    void Clear();
    long Size();
    void Insert(long p, ListEntry x);
    void Delete(long p, ListEntry &x);
    void Retrieve(long p, ListEntry &x);
    long Search(ListEntry x);
    string toString();
   
  private:
    // declaracao de tipos
    struct ListNode; // serah definido logo adiante no codigo

    typedef ListNode *ListPointer;
    struct ListNode
    { ListEntry Entry;   		// tipo de dado colocado na lista
      ListPointer NextNode;   	// ligacao para proximo elemento na lista
    };

    // campos
    ListPointer head;           // inicio da lista
    long count;                 // numero de elementos

    // metodos privados
    void SetPosition(long p, ListPointer &current);
}; 
//---------------------------------------------------------------
template< class ListEntry >
List<ListEntry>::List()
{ head = NULL;
  count = 0;
}
//---------------------------------------------------------------
template< class ListEntry >
List<ListEntry>::~List()
{ 
    Clear();
}
//---------------------------------------------------------------
template< class ListEntry >
bool List<ListEntry>::Empty()
{
    return (head == NULL);
}
//---------------------------------------------------------------
template< class ListEntry >
bool List<ListEntry>::Full()
{
   return false;
}
//---------------------------------------------------------------
template< class ListEntry >
void List<ListEntry>::Clear()
{ ListPointer q;

  while (head != NULL)
  {  q = head;
     head = head->NextNode;
     delete q;
  }
  count = 0;
}
//---------------------------------------------------------------
template< class ListEntry >
long List<ListEntry>::Size()
{
   return count;
}
//---------------------------------------------------------------
template< class ListEntry >
void List<ListEntry>::Insert(long p, ListEntry x)
{ ListPointer NewNode, current;

  if (p < 1 || p > count+1)
  { cout << "Posicao invalida" << endl;
    abort();
  }
  NewNode = new ListNode;
  NewNode->Entry = x;
  if(p == 1) 
  {  NewNode->NextNode = head;
     head = NewNode;
  }
  else
  {  SetPosition(p-1,current);
     NewNode->NextNode = current->NextNode;
     current->NextNode = NewNode;
  }
  count++;
}
//---------------------------------------------------------------
template< class ListEntry >
void List<ListEntry>::Delete(long p, ListEntry &x)
{ ListPointer Node, current;

  if (p < 1 || p > count)
  { cout << "Posicao invalida" << endl;
    abort();
  }
  if(p == 1) 
  {  Node = head;
     head = Node->NextNode;
  }
  else
  {  SetPosition(p-1,current);
     Node = current->NextNode;
     current->NextNode = Node->NextNode;
  }
  x = Node->Entry;
  delete Node;
  count = count - 1;
}
//---------------------------------------------------------------
template< class ListEntry >
void List<ListEntry>::Retrieve(long p, ListEntry &x)
{ ListPointer current;

  SetPosition(p,current);
  x = current->Entry;
}
//---------------------------------------------------------------
template< class ListEntry >
long List<ListEntry>::Search(ListEntry x)
{ long p=1;
  ListPointer q=head;

  while (q != NULL && q->Entry != x) 
  {  q = q->NextNode;
     p++;
  }
  return (q == NULL ? 0 : p);
}
//---------------------------------------------------------------
template< class ListEntry >
string List<ListEntry>::toString()
{ ListPointer q=head;
  string s;
  stringstream ss;

  while (q != NULL)
  {  ss << q->Entry << ",";
     q = q->NextNode;
  }
  s = ss.str();
  return s.substr(0,s.length()-1);
}
//---------------------------------------------------------------
template< class ListEntry >
void List<ListEntry>::SetPosition(long p, ListPointer &current)
{ long i;

  if (p < 1 || p > count+1)
  { cout << "Posicao invalida" << endl;
    abort();
  }
  current = head;
  for(i=2; i<=p; i++)
      current = current->NextNode;
}

#endif /* LISTTEMPLATE_H */
