/*
 * List.cpp
 *
 *  Created on:
 *      Author:
 */
#include "List.h"
//---------------------------------------------------------------
List::List()
{
  head = NULL;
  count = 0;
}
//---------------------------------------------------------------
List::~List()
{
  Clear();
}
//---------------------------------------------------------------
bool List::Empty()
{
  return (head == NULL);
}
//---------------------------------------------------------------
bool List::Full()
{
   return false;
}
//---------------------------------------------------------------
void List::Clear()
{ ListPointer q;

  while (head != NULL)
  {  q = head;
     head = head->NextNode;
     delete q;
  }
  count = 0;
}
//---------------------------------------------------------------
long List::Size()
{
   return count;
}
//---------------------------------------------------------------
void List::Insert(long p, ListEntry x)
{ ListPointer NewNode, current;

  if (p < 1 || p > count+1)
  { cout << "Posicao invalida" << endl;
    abort();
  }
  NewNode = new ListNode;
  NewNode->Entry = x;
  if(p == 1)
  {  NewNode->NextNode = head;
     head = NewNode;
  }
  else
  {  SetPosition(p-1,current);
     NewNode->NextNode = current->NextNode;
     current->NextNode = NewNode;
  }
  count++;
}
//---------------------------------------------------------------
void List::Delete(long p, ListEntry &x)
{ ListPointer Node, current;

  if (p < 1 || p > count)
  { cout << "Posicao invalida" << endl;
    abort();
  }
  if(p == 1)
  {  Node = head;
     head = Node->NextNode;
  }
  else
  {  SetPosition(p-1,current);
     Node = current->NextNode;
     current->NextNode = Node->NextNode;
  }
  x = Node->Entry;
  delete Node;
  count = count - 1;
}
//---------------------------------------------------------------
void List::Retrieve(long p, ListEntry &x)
{ ListPointer current;

  SetPosition(p,current);
  x = current->Entry;
}
//---------------------------------------------------------------
long List::Search(ListEntry x)
{ long p=1;
  ListPointer q=head;

  while (q != NULL && q->Entry != x)
  {  q = q->NextNode;
     p++;
  }
  return (q == NULL ? 0 : p);
}
//---------------------------------------------------------------
string List::toString()
{ ListPointer q=head;
  string s;
  stringstream ss;

  while (q != NULL)
  {  ss << q->Entry << ",";
     q = q->NextNode;
  }
  s = ss.str();
  return "[" + s.substr(0,s.length()-1) + "]";
}
//---------------------------------------------------------------
string List::toStringAddr()
{ ListPointer q=head;
  string s;
  stringstream ss;

  while (q != NULL)
  {  ss << q << ",";
     q = q->NextNode;
  }
  s = ss.str();
  return "[" + s.substr(0,s.length()-1) + "]";
}
//---------------------------------------------------------------
void List::SetPosition(long p, ListPointer &current)
{ long i;

  if (p < 1 || p > count+1)
  { cout << "Posicao invalida" << endl;
    abort();
  }
  current = head;
  for(i=2; i<=p; i++)
      current = current->NextNode;
}
//---------------------------------------------------------------
long List::GetAddr(ListEntry x)
{ ListPointer current=NULL;
  long p = Search(x);
  if(p != 0)
    SetPosition(p, current);
  return (long)current;
}
//---------------------------------------------------------------
bool List::Swap(ListEntry a, ListEntry b)
{ // sua implementacao vem aqui

}
//---------------------------------------------------------------
